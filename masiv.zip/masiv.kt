//Насырбеков Алихан
fun main(){

    val arrayList = arrayListOf<Int>(1, 2, 3)
    val arrayList2 = arrayListOf<Int>(4, 5, 6)
    val value = arrayList[0]+arrayList2[0]
    val value2 = arrayList[1]+arrayList2[1]
    val value3 = arrayList[2]+arrayList2[2]
    println(value+value2+value3)



    val numbers: IntArray = intArrayOf(5, -3, 15, 61, 29, 10, -2 ,7)

    println(numbers.maxOrNull())






}
