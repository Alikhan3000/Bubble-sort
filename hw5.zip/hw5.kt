fun main(){
    val a = 0
    if(a < 1|| a > 100) {
        println("«21 год», «32 года», «12 лет»")
    }

}

