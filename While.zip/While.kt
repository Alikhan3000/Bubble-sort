//Насырбеков Алихан
fun main() {
    val square: ArrayList<String> = arrayListOf("* * * * *", "* * * * *", "* * * * *", "* * * * *")
    for (i: Int in 0 until square.size) {
        println(square[i])

    }


    val triangle = arrayListOf<String>("*", "* *", "* * *", "* * * *", "* * * * *")
    for (i in 0..4)
        println(triangle[i])


    





}


