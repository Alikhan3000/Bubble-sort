// Насырбеков Алихан
fun main(){
    val a = 7
    val v = a %2 ==0
    val t = a %5 ==0


    when (true){
        v-> println("a is even")
        t-> println("a is divisible by 5")
        else -> println("a is not even and not divisible by 5")

        }
        }



